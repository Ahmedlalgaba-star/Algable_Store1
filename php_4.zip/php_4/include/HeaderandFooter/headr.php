<!DOCTYPE html>
<html lang="ar">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سلة التسوق</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
	<link rel="stylesheet" href="css/header.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/table.css">
<link rel="stylesheet" href="css/search.css" />
</head>

<body>

    <!-- Header -->
    <header>
        <div class="logo">متجر الجبل الكتروني</div>
<br>
        <!-- زر الهامبرغر -->
        <div class="hamburger-menu" onclick="toggleMenu()">
            <div></div>
            <div></div>
            <div></div>
        </div>

        <!-- الروابط العادية -->
        <div class="nav-links">
            <a href="shop.php">الصفحة الرئيسية</a>
            <a href="cart.php">سلة التسوق</a>
            <a href="contact.php">اتصل بنا</a>
        </div>

        <!-- قائمة الجوال -->
        <div class="mobile-nav" id="mobile-nav">
            <span class="close-menu" onclick="toggleMenu()">&times;</span>
            <a href="admin/login.php">الادمن</a>
            <a href="shop.php">الصفحة الرئيسية</a>
			<a href="shop.php">جميع المنتجات</a>
            <a href="storyproducts.php">الهواتف الذكية</a>
            <a href="mbusinproducts.php" > ملابس ادوات واجهزة منزلية</a>
            <a href="sdevelopproducts.php">عطورات </a>
            <a href="cart.php">سلة التسوق</a>
            <a href="contact.php">اتصل بنا</a>
        </div>
	
	
    </header>

