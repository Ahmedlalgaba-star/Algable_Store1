<?php
include 'db/db_connect.php';
session_start(); // بدء الجلسة

// الحصول على قيمة البحث
$search = isset($_GET['search']) ? $_GET['search'] : '';

// تعديل استعلام SQL ليشمل البحث مع استخدام Prepared Statements
$sql = "SELECT 
              storyproducts.*, 
            COALESCE((SELECT class.class_name FROM class WHERE class.class_id = storyproducts.class_id ), 'غير مصنف') AS class_name 
        FROM storyproducts  
        WHERE storyproducts.class_id=2 AND storyproducts.name LIKE ?";
$stmt = $conn->prepare($sql);
$search_term = "%$search%";
$stmt->bind_param('s', $search_term);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>الإدارة والاعمال</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <style>
        .quantity-input {
            width: 50px;
            text-align: center;
            padding: 5px;
            font-size: 16px;
        }
        .cart-icon h1 {
            font-size: 22px;
            margin-left: 10px;
        }
        .cart-icon {
            font-size: 30px;
            color: #3b82f6;
            cursor: pointer;
        }
        .cart-icon:hover {
            color: #1d4ed8;
        }
        .product-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            background-color: #fff;
            text-align: center;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .product-card img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }
        .product-card img:hover {
            transform: scale(1.05);
        }
        .product-card h4 {
            margin-top: 10px;
            font-size: 18px;
            color: #333;
        }
        .product-card span {
            font-size: 14px;
            color: #555;
        }
        .filter-container {
            margin-bottom: 20px;
        }
    </style>
</head>

<body>

    <?php include 'HeaderandFooter/header.php'; ?>

    <div class="filter-container">
        <form action="shop.php" method="get">
            <input type="text" name="search" placeholder="ابحث عن المنتج..." value="<?php echo htmlspecialchars($search); ?>" />
            <button type="submit">بحث</button>
        </form>
    </div>

    <div>
        <div class="container main">
            <h2>الإدارة والاعمال</h2>
        </div>
    </div>

    <!-- الروابط العادية -->
    <div class="nav-linkss">
        <a href="shop.php">جميع المنتجات</a>
        <a href="storyproducts.php">القصة والرواية</a>
        <a href="mbusinproducts.php">الإدارة والاعمال</a>
        <a href="sdevelopproducts.php">تطوير الذات</a>
    </div>

    <section id='product1' class='section-p1'>
        <div class="product-container">
            <?php

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class="product-card">
                        <img src="admin/images/<?php echo $row["image1"]; ?>" alt="" />
                        <div class="des">
                            <span>إسم الكتاب: <?php echo $row["name"]; ?></span>
                            <span>النوع: <?php echo $row["class_name"]; ?></span>
                            <h4>السعر: <?php echo $row["price"]; ?> ريال</h4>
                            <label for="quantity<?php echo $row['id']; ?>">حدد الكمية:</label>
                            <input type="number" id="quantity<?php echo $row['id']; ?>" value="1" min="1" max="<?php echo $row['quantity']; ?>" class="quantity-input" oninput="validateQuantity(<?php echo $row['id']; ?>, <?php echo $row['quantity']; ?>)" />
                        </div>
                        <a href="javascript:void(0);" onclick="addToCart('<?php echo urlencode($row['image1']); ?>', '<?php echo urlencode($row['name']); ?>', '<?php echo urlencode($row['price']); ?>', document.getElementById('quantity<?php echo $row['id']; ?>').value);" class="cart-icon">
                            🛒
                        </a>
                    </div>
            <?php
                }
            } else {
                echo "<p>لا توجد نتائج مطابقة للبحث</p>";
            }
            ?>
        </div>
    </section>

    <?php include 'HeaderandFooter/footer.php'; ?>

    <script src="script.js"></script>
    <script src="js/script.js"></script>
    <script>
        // دالة لإضافة المنتج إلى السلة مع الكمية
        function addToCart(image, name, price, quantity) {
            var result = confirm("هل تريد إضافة هذا المنتج إلى السلة؟");
            if (result) {
                window.location.href = "add_to_cart.php?image=" + image + "&name=" + name + "&price=" + price + "&quantity=" + quantity;
                alert("تم إضافة المنتج إلى السلة!");
            } else {
                alert("لم يتم إضافة المنتج إلى السلة.");
            }
        }

        function validateQuantity(id, maxQuantity) {
            let input = document.getElementById('quantity' + id);
            if (input.value > maxQuantity) {
                alert("الكمية المتاحة في المخزون هي " + maxQuantity + " فقط.");
                input.value = maxQuantity;
            }
        }
    </script>

    <script>
        window.addEventListener("unload", function() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "logout.php", false);
            xhr.send();
        });
    </script>
</body>

</html>
