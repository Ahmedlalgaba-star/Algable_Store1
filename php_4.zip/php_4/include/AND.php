<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "store";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

$language = $_GET['lang'] ?? 'ar';
?>
<!DOCTYPE html>
<html lang="<?php echo $language; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>متجرنا الإلكتروني</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<nav>
    <a href="?lang=ar">العربية</a> |
    <a href="?lang=en">English</a>
</nav>

<section id="product1">
    <h2>منتجاتنا</h2>
    <div class="pro-container">
        <?php
        $query = "SELECT * FROM storyproducts";
        $result = $conn->query($query);
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='pro'>
                        <img src='admin/images/{$row['image1']}' alt='{$row['name']}'>
                        <div class='des'>
                            <span>{$row['name']}</span>
                            <h5>{$row['price']} ريال</h5>
                        </div>
                        <a href='#' class='cart-icon' onclick='addToCart(\"{$row['name']}\", {$row['price']})'>🛒</a>
                      </div>";
            }
        } else {
            echo "<p>لا توجد منتجات.</p>";
        }
        ?>
    </div>
</section>

<input type="text" id="search-input" placeholder="ابحث عن منتجات...">
<button onclick="startVoiceSearch()">🔊</button>

<div id="cart">
    <h3>سلة التسوق</h3>
    <div id="cart-content"></div>
    <button onclick="checkout()">الدفع الآن</button>
</div>

<form method="POST" action="payment.php">
    <div class="payment-methods">
        <div class="payment-option" onclick="selectPaymentMethod('paypal')">
            <i class="fab fa-paypal"></i> بايبال
        </div>
        <div class="payment-option" onclick="selectPaymentMethod('stcpay')">
            <i class="fas fa-wallet"></i> STC Pay
        </div>
        <div class="payment-option" onclick="selectPaymentMethod('bitcoin')">
            <i class="fas fa-credit-card"></i> بيتكوين
        </div>
    </div>
    <input type="hidden" name="payment_method" id="payment_method">
    <button type="submit">الدفع الآن</button>
</form>

<div id="ar-section">
    <h3>جرب المنتج في الواقع المعزز</h3>
    <button onclick="launchAR()">تشغيل AR</button>
</div>

<script>
function startVoiceSearch() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.start();
    recognition.onresult = function(event) {
        document.getElementById("search-input").value = event.results[0][0].transcript;
    };
}

function addToCart(name, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({ name, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    showCart();
}

function showCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartContent = document.getElementById("cart-content");

    if (cart.length > 0) {
        let total = 0;
        let itemsHTML = "";
        cart.forEach((item) => {
            total += parseFloat(item.price);
            itemsHTML += `<p>${item.name} - ${item.price} ريال</p>`;
        });
        cartContent.innerHTML = itemsHTML + `<h4>الإجمالي: ${total.toFixed(2)} ريال</h4>`;
    } else {
        cartContent.innerHTML = "<p>السلة فارغة.</p>";
    }
}

function checkout() {
    window.location.href = 'checkout.php';
}

document.addEventListener("DOMContentLoaded", showCart);

function selectPaymentMethod(method) {
    document.getElementById("payment_method").value = method;
}

function launchAR() {
    alert("يتم الآن تشغيل الواقع المعزز.");
}
</script>

</body>
</html>
