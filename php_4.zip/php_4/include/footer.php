<html>
    <body>
    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-content">
                <h3>متجرالجبل الالكتروني</h3>
                <p>نحن نقدم أفضل المنتجات و بأفضل الأسعار.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>

            <div class="footer-contact">
                <h4>تواصل معنا</h4>
                <p><i class="fas fa-phone"></i> 777073957</p>
                <p><i class="fas fa-envelope"></i> ahmedgabal5454@amil.com</p>
            </div>
        </div>

        <hr>
        <p class="footer-bottom">جميع الحقوق محفوظة &copy; 2025 متجرالجبل الالكتروني</p>
    </footer>

   <script src="../js/script.js"></script>

</body>
</html>
