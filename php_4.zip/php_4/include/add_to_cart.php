<?php
session_start(); // بدء الجلسة

// التحقق من وجود بيانات المنتج المرسلة
if (isset($_GET['image']) && isset($_GET['name']) && isset($_GET['price']) && isset($_GET['quantity'])) {
    $product = [
        'image' => $_GET['image'],
        'name' => $_GET['name'],
        'price' => $_GET['price'],
        'quantity' => $_GET['quantity'] // إضافة الكمية
    ];

    // التحقق إذا كانت السلة موجودة في الجلسة
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = []; // إذا كانت السلة فارغة، نبدأ مصفوفة جديدة
    }

    // التحقق إذا كان المنتج موجود في السلة بالفعل
    $found = false;
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['name'] == $product['name']) {
            // إذا كان المنتج موجودًا في السلة، نضيف الكمية
            $_SESSION['cart'][$key]['quantity'] += $product['quantity'];
            $found = true;
            break;
        }
    }

    // إذا لم يتم العثور على المنتج في السلة، نضيفه للسلة
    if (!$found) {
        $_SESSION['cart'][] = $product;
    }

    // إعادة توجيه المستخدم إلى الصفحة الرئيسية بعد إضافة المنتج
    header("Location: shop.php");
    exit();
} else {
    // في حالة عدم وجود بيانات المنتج أو الكمية، إعادة توجيه إلى الصفحة الرئيسية
    header("Location: shop.php");
    exit();
}
?>
