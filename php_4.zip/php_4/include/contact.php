<?php include 'HeaderandFooter/headr.php'; ?>
<div class="container">
    <h1>اتصل بنا</h1>
    <div class="contact-info">
        <h2>معلومات الاتصال</h2>
        <p>يمكنك التواصل معنا عبر الطرق التالية:</p>
        <p><i class="fas fa-phone"></i><strong>رقم الهاتف:</strong> <a href="tel:+967777073957">+967777073957</a></p>
        <p><i class="fas fa-envelope"></i><strong>البريد الإلكتروني:</strong> <a href="ahmedgabal5454@amil.com">ahmedgabal5454@amil.com</a></p>
        <p><i class="fab fa-whatsapp"></i><strong>واتساب:</strong> <a href="https://wa.me/967777073957" target="_blank">تواصل معنا عبر واتساب</a></p>
        <a href="services.php" class="cta-button">استعرض خدماتنا</a>
    </div>
</div>


<?php include 'HeaderandFooter/footer.php'; ?>