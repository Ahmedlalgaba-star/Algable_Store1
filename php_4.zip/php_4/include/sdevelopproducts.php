<?php
include 'db/db_connect.php';
session_start(); // بدء الجلسة

// الحصول على قيمة البحث
$search = isset($_GET['search']) ? $_GET['search'] : '';

// تعديل استعلام SQL ليشمل البحث
$sql = "SELECT 
              storyproducts.*,  
            COALESCE((SELECT class.class_name FROM class WHERE class.class_id = storyproducts.class_id ), 'غير مصنف') AS class_name 
        FROM storyproducts  
        WHERE storyproducts.class_id=3 && storyproducts.name LIKE '%$search%'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>متجر الجبل الالكتروني</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="style.css" />
    <style>
        /* يمكن تحسين CSS هنا حسب احتياجاتك */
    </style>
</head>

<body>

    <?php include 'HeaderandFooter/header.php'; ?>

    <div>
        <div class="container main">
            <h2>متجر الجبل الالكتروني</h2>
        </div>
    </div>

    <!-- الروابط العادية -->
    <div class="nav-linkss">
        <a href="shop.php">جميع المنتجات</a>
        <a href="storyproducts.php">ملابس</a>
        <a href="mbusinproducts.php">الهواتف الذكية</a>
        <a href="sdevelopproducts.php">اكسسوارات ومستلزمات</a>
    </div>

    <section id='product1' class='section-p1'>
        <div class='pro-container'>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
            ?>
                    <div class='pro'>
                        <img src="admin/images/<?php echo $row["image1"]; ?>" alt="" />
                        <div class='des'>
                            <span>إسم المنتج: <?php echo $row["name"]; ?></span>
                            <span>النوع: <?php echo $row["class_name"]; ?></span>
                            <h4>السعر: <?php echo $row["price"]; ?> ريال</h4>
                            <!-- إدخال الكمية مع التحقق من الحد الأقصى -->
                            <br>
                            <!-- إضافة خانة لتحديد الكمية -->
                            حدد الكمية:
                            <input type="number" id="quantity<?php echo $row['id']; ?>" value="1" min="1" max="<?php echo $row['quantity']; ?>" class="quantity-input" oninput="validateQuantity(<?php echo $row['id']; ?>, <?php echo $row['quantity']; ?>)" />
                        </div>

                        <!-- زر السلة مع إرسال الكمية -->
                        <a href="javascript:void(0);" onclick="addToCart('<?php echo urlencode($row['image1']); ?>', '<?php echo urlencode($row['name']); ?>', '<?php echo urlencode($row['price']); ?>', document.getElementById('quantity<?php echo $row['id']; ?>').value);" class="cart-icon">
                            <h1>🛒</h1><i class="fas fa-shopping-cart"></i>
                        </a>
                    </div>
            <?php
                }
            } else {
                echo "<p>لا توجد منتجات حالياً. سيتم إضافة المزيد قريباً.</p>";
            }
            ?>
        </div>
    </section>

    <?php include 'HeaderandFooter/footer.php'; ?>
    <script src="js/script.js"></script>
    <script src="script.js"></script>
</body>

</html>

<script>
    // دالة لإضافة المنتج إلى السلة مع الكمية
    function addToCart(image, name,
     price, quantity) {
        // عرض نافذة تأكيد للمستخدم
        var result = confirm("هل تريد إضافة هذا المنتج إلى السلة؟");

        if (result) {
            // إذا وافق المستخدم، نقوم بإضافة المنتج إلى السلة
            window.location.href = "add_to_cart.php?image=" + image + "&name=" + name + "&price=" + price + "&quantity=" + quantity;
            // إظهار رسالة تم إضافة المنتج للسلة
            alert("تم إضافة المنتج إلى السلة!");
        } else {
            // إذا رفض المستخدم، لا يحدث شيء
            alert("لم يتم إضافة المنتج إلى السلة.");
        }
    }

    // التحقق من الكمية المتاحة
    function validateQuantity(id, maxQuantity) {
        let input = document.getElementById('quantity' + id);
        if (input.value > maxQuantity) {
            alert("الكمية المتاحة في المخزون هي " + maxQuantity + " فقط.");
            input.value = maxQuantity;
        }
    }
</script>

<script>
    // تنفيذ عملية تسجيل الخروج عند إغلاق الصفحة
    window.addEventListener("unload", function () {
        // استدعاء سكربت PHP لتسجيل الخروج
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "logout.php", false);
        xhr.send();
    });
</script>