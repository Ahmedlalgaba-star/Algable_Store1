<?php
// الاتصال بقاعدة البيانات
$host = "localhost";
$user = "root";
$password = "";
$dbname = "jbaree"; // تأكد من تطابق الاسم بدون (1) إن تطلب الأمر

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

// ============ 1. عدد الطلبات اليومية ============
$orders_sql = "SELECT DATE(created_at) AS order_date, COUNT(*) AS total_orders
               FROM orders
               GROUP BY DATE(created_at)
               ORDER BY order_date DESC
               LIMIT 7";
$orders_result = $conn->query($orders_sql);
$orders_data = [];
while ($row = $orders_result->fetch_assoc()) {
    $orders_data[] = $row;
}

// ============ 2. إجمالي الدخل اليومي ============
$sales_sql = "SELECT DATE(created_at) AS sale_date, SUM(total_price) AS total_income
              FROM orders
              GROUP BY DATE(created_at)
              ORDER BY sale_date DESC
              LIMIT 7";
$sales_result = $conn->query($sales_sql);
$sales_data = [];
while ($row = $sales_result->fetch_assoc()) {
    $sales_data[] = $row;
}

// ============ 3. المنتجات الأكثر مبيعًا ============
$top_sql = "SELECT p.product_name, SUM(od.quantity) AS total_sold
            FROM order_details od
            JOIN products p ON od.product_id = p.id
            GROUP BY od.product_id
            ORDER BY total_sold DESC
            LIMIT 5";
$top_result = $conn->query($top_sql);
$top_products = [];
while ($row = $top_result->fetch_assoc()) {
    $top_products[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم تسويقية</title>
    <style>
        body { font-family: Arial; direction: rtl; background: #f4f4f4; padding: 20px; }
        h2 { color: #333; }
        pre { background: #fff; padding: 10px; border: 1px solid #ccc; overflow: auto; }
    </style>
</head>
<body>

    <h2>📦 عدد الطلبات اليومية (آخر 7 أيام):</h2>
    <pre><?php echo json_encode($orders_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?></pre>

    <h2>💰 إجمالي الدخل اليومي:</h2>
    <pre><?php echo json_encode($sales_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?></pre>

    <h2>🔥 المنتجات الأكثر مبيعًا:</h2>
    <pre><?php echo json_encode($top_products, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?></pre>

</body>
</html>
