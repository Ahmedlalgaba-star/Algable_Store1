<?php
include 'db/db_connect.php';
session_start(); // بدء الجلسة

// السعر الإجمالي للطلب (افترض أنك تقوم بحسابها مسبقًا)
$total_price = 100; // على سبيل المثال، السعر الإجمالي 100 ريال

// عند إرسال النموذج
if(isset($_POST['pay'])) {
    $payment_method = $_POST['payment_method'];

    // إرسال طريقة الدفع
    if($payment_method == 'paypal') {
        header('Location: paypal_payment.php');  // تحويل إلى بايبال
    }
    elseif($payment_method == 'stcpay') {
        header('Location: stcpay_payment.php');  // تحويل إلى STC Pay
    }
    elseif($payment_method == 'tap') {
        header('Location: tap_payment.php');  // تحويل إلى Tap Payments
    }
}

?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختيار طريقة الدفع</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        /* تحسين المظهر */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
        }

        .payment-methods {
            margin: 20px;
        }

        .payment-option {
            background-color: #fff;
            padding: 15px;
            margin: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: all 0.3s;
        }

        .payment-option:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .payment-option i {
            font-size: 40px;
            margin-right: 10px;
        }

        .payment-option span {
            font-size: 18px;
            font-weight: bold;
        }

        .payment-option.selected {
            background-color: #007bff;
            color: white;
        }

        .submit-button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .submit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h2>اختيار طريقة الدفع</h2>

    <form method="POST">
        <div class="payment-methods">
            <div class="payment-option" id="paypal" onclick="selectPaymentMethod('paypal')">
                <i class="fab fa-paypal"></i>
                <span>بايبال</span>
            </div>

            <div class="payment-option" id="stcpay" onclick="selectPaymentMethod('stcpay')">
                <i class="fas fa-wallet"></i>
                <span>STC Pay</span>
            </div>

            <div class="payment-option" id="tap" onclick="selectPaymentMethod('tap')">
                <i class="fas fa-credit-card"></i>
                <span>بطاقة ائتمان (Visa/MasterCard)</span>
            </div>
        </div>

        <!-- المبلغ الإجمالي الذي سيتم دفعه -->
        <h4>المبلغ الإجمالي: <?php echo $total_price; ?> ريال</h4>

        <!-- زر الدفع -->
        <button type="submit" name="pay" class="submit-button">الدفع</button>
    </form>

    <script>
        // تحديد طريقة الدفع
        function selectPaymentMethod(method) {
            // إزالة الاختيار من جميع الطرق
            let methods = document.querySelectorAll('.payment-option');
            methods.forEach(function(methodDiv) {
                methodDiv.classList.remove('selected');
            });

            // إضافة الاختيار للطريقة المحددة
            let selectedMethod = document.getElementById(method);
            selectedMethod.classList.add('selected');

            // تحديث قيمة الدفع في النموذج
            document.querySelector("input[name='payment_method']").value = method;
        }
        
        // اختيار طريقة الدفع الافتراضية (بايبال)
        selectPaymentMethod('paypal');
    </script>

    <!-- إضافة الحقل المخفي لاختيار طريقة الدفع -->
    <input type="hidden" name="payment_method" value="">

</body>
</html>
