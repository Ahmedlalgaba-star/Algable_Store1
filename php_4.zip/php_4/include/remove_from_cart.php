<?php
session_start(); // بدء الجلسة

// عرض الرسالة إذا كانت موجودة في الجلسة
if (isset($_SESSION['message'])) {
    echo "<p>" . $_SESSION['message'] . "</p>";
    unset($_SESSION['message']); // مسح الرسالة بعد عرضها
}

// عرض محتويات السلة
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    echo "<h2>سلة التسوق</h2>";
    foreach ($_SESSION['cart'] as $key => $item) {
        echo "<div>";
        echo "<p>اسم المنتج: " . $item['name'] . "</p>";
        echo "<p>السعر: " . $item['price'] . " ريال</p>";
        echo "<a href='?shop=$key'>حذف من السلة</a>";
        echo "</div>";
    }
} else {
    echo "<p>السلة فارغة!</p>";
}
?>