<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مشروع متجر إلكتروني</title>
    
    <!-- روابط CSS الخاصة بك -->
    <link rel="stylesheet" href="styles.css">

    <!-- إضافة روابط مكتبات خارجية (إذا كان هناك حاجة) -->
    <script src="https://www.paypal.com/sdk/js?client-id=YOUR_CLIENT_ID"></script> <!-- ربط مكتبة PayPal -->
</head>
<body>
    <!-- واجهة المستخدم الخاصة بك -->
    <div>
        <!-- مثال على نموذج (form) للتحقق من البيانات -->
        <form id="form">
            <label for="name">الاسم:</label>
            <input type="text" id="name" required>
            <button type="submit">إرسال</button>
        </form>
    </div>

    <!-- حاوية الدفع الإلكتروني (PayPal) -->
    <div id="paypal-button-container"></div>

    <!-- حاوية نتائج البحث -->
    <input type="text" id="search-input" placeholder="ابحث عن منتج...">
    <ul id="search-suggestions"></ul>

    <!-- حاوية لتتبع الطلبات -->
    <div id="order-status"></div>

    <!-- نوافذ منبثقة -->
    <div id="myModal" class="modal">
        <span class="close">&times;</span>
        <p>هذه نافذة منبثقة!</p>
    </div>
    <button id="myBtn">فتح النافذة المنبثقة</button>

    <!-- ربط ملف JavaScript -->
    <script src="script.js"></script> <!-- هنا يتم ربط ملف JavaScript الخاص بك -->
</body>
</html>
