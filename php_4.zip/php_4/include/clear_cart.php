<?php
include 'db/db_connect.php';
session_start();

// الحصول على قيمة البحث
$search = isset($_GET['search']) ? $_GET['search'] : '';

// جلب المنتجات حسب الفئة والبحث
$sql = "SELECT 
            storyproducts.*, 
            COALESCE((SELECT class.class_name FROM class WHERE class.class_id = storyproducts.class_id ), 'غير مصنف') AS class_name 
        FROM storyproducts  
        WHERE storyproducts.class_id = 2 AND storyproducts.name LIKE '%$search%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>الإدارة والأعمال</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <?php include 'HeaderandFooter/header.php'; ?>

    <div class="container main">
        <h2>الإدارة والأعمال</h2>
    </div>

    <!-- روابط تصفح الأقسام -->
    <div class="nav-linkss">
        <a href="shop.php">جميع المنتجات</a>
        <a href="storyproducts.php">القصة والرواية</a>
        <a href="mbusinproducts.php">الإدارة والأعمال</a>
        <a href="sdevelopproducts.php">تطوير الذات</a>
    </div>

    <!-- عرض المنتجات -->
    <section id="product1" class="section-p1">
        <div class="pro-container">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="pro">
                        <img src="admin/images/<?php echo $row['image1']; ?>" alt="صورة المنتج" />
                        <div class="des">
                            <span>اسم الكتاب: <?php echo $row['name']; ?></span><br>
                            <span>النوع: <?php echo $row['class_name']; ?></span>
                            <h4>السعر: <?php echo $row['price']; ?> ريال</h4>
                            <label>حدد الكمية:</label>
                            <input type="number" 
                                   id="quantity<?php echo $row['id']; ?>" 
                                   value="1" 
                                   min="1" 
                                   max="<?php echo $row['quantity']; ?>" 
                                   class="quantity-input"
                                   oninput="validateQuantity(<?php echo $row['id']; ?>, <?php echo $row['quantity']; ?>)" />
                        </div>
                        <a href="javascript:void(0);" 
                           onclick="addToCart('<?php echo urlencode($row['image1']); ?>', '<?php echo urlencode($row['name']); ?>', '<?php echo urlencode($row['price']); ?>', document.getElementById('quantity<?php echo $row['id']; ?>').value);" 
                           class="cart-icon">
                           <h1>🛒</h1><i class="fas fa-shopping-cart"></i>
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>لا توجد نتائج مطابقة للبحث</p>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'HeaderandFooter/footer.php'; ?>

    <!-- سكربتات -->
    <script>
        function addToCart(image, name, price, quantity) {
            if (confirm("هل تريد إضافة هذا المنتج إلى السلة؟")) {
                window.location.href = "add_to_cart.php?image=" + image + "&name=" + name + "&price=" + price + "&quantity=" + quantity;
                alert("تم إضافة المنتج إلى السلة!");
            } else {
                alert("لم يتم إضافة المنتج إلى السلة.");
            }
        }

        function validateQuantity(id, maxQuantity) {
            const input = document.getElementById('quantity' + id);
            if (parseInt(input.value) > parseInt(maxQuantity)) {
                alert("الكمية المتاحة في المخزون هي " + maxQuantity + " فقط.");
                input.value = maxQuantity;
            }
        }

        window.addEventListener("unload", function() {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "logout.php", false);
            xhr.send();
        });
    </script>
</body>
</html>

