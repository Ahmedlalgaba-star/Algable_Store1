   <?php
session_start();
$totalPrice = 0; // متغير لتخزين إجمالي السعر

// دالة لحذف منتج من السلة
if (isset($_GET['remove'])) {
    $removeIndex = $_GET['remove'];
    unset($_SESSION['cart'][$removeIndex]);
    header("Location: cart.php"); // إعادة تحميل الصفحة بعد الحذف
    exit();
}

// دالة لإفراغ السلة بالكامل
if (isset($_GET['clear'])) {
    unset($_SESSION['cart']);
    header("Location: cart.php"); // إعادة تحميل الصفحة بعد إفراغ السلة
    exit();
}

// دالة لتصفية السلة حسب السعر
if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
    if ($filter == 'low-to-high') {
        usort($_SESSION['cart'], function($a, $b) {
            return $a['price'] - $b['price'];
        });
    } elseif ($filter == 'high-to-low') {
        usort($_SESSION['cart'], function($a, $b) {
            return $b['price'] - $a['price'];
        });
    }
}
?>
	<!-- Header -->
<?php include 'HeaderandFooter/headr.php'; ?>
    <!-- المحتوى الرئيسي -->
    <div class="container">
        <h2>🛒 سلة التسوق</h2>

        <!-- محتوى السلة هنا -->
        <table>
            <thead>
                <tr>
                    <th>الصورة</th>
                    <th>اسم المنتج</th>
                    <th>السعر</th>
                    <th>العدد</th>
                    <th>إجمالي السعر</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0):
                    $totalPrice = 0;
                    foreach ($_SESSION['cart'] as $index => $item):
                        $totalPrice += $item['price'] * $item['quantity']; 
                ?>
                <tr>
                    <td><img src="admin/images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" width="100" /></td>
                    <td><?php echo $item['name']; ?></td>
                    <td><?php echo $item['price']; ?> ريال</td>
                    <td><?php echo $item['quantity']; ?></td> <!-- عرض العدد فقط كرقم -->
                    <td><?php echo $item['price'] * $item['quantity']; ?> ريال</td>
                    <td><a href="javascript:void(0);" class="btn-remove" onclick="confirmRemove(<?php echo $index; ?>)"><i class="fas fa-trash"></i> حذف</a></td>
                </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="4">الإجمالي الكلي:</td>
                    <td><?php echo $totalPrice; ?> ريال</td>
                </tr>
                <?php else: ?>
                <tr>
                    <td colspan="6">السلة فارغة</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
<br>
        <!-- إضافة زر لتصفية السلة -->
        <label for="filter">تصفية المنتجات:</label>
        <select id="filter" onchange="filterCart(this.value)">
            <option value="all">كل المنتجات</option>
            <option value="low-to-high">السعر من الأقل إلى الأعلى</option>
            <option value="high-to-low">السعر من الأعلى إلى الأقل</option>
        </select>

        <!-- إضافة زر لإفراغ السلة -->
        <br><br><a href="javascript:void(0);" class="btn-clear" onclick="confirmClearCart()">إفراغ السلة</a>

        <!-- إضافة زر لإرسال الطلب عبر واتساب -->
        <br><button onclick="sendOrder()" class="btn-clear">إرسال الطلب عبر واتساب</button>

        <?php if (isset($_GET['clear'])): ?>
            <p class="success-message">تم إفراغ السلة بنجاح.</p>
        <?php endif; ?>
    </div>
   <script>
        // دالة لتبديل ظهور القائمة على الجوال
        function toggleMenu() {
            var menu = document.getElementById('mobile-nav');
            menu.classList.toggle('active');
        }

        // دالة لتأكيد الحذف
        function confirmRemove(index) {
            if (confirm("هل أنت متأكد أنك تريد حذف هذا المنتج؟")) {
                window.location.href = `cart.php?remove=${index}`;
            }
        }

        // دالة لتصفية السلة
        function filterCart(criteria) {
            window.location.href = `cart.php?filter=${criteria}`;
        }

        // دالة لإرسال الطلب عبر واتساب
        function sendOrder() {
            let cartItems = <?php echo json_encode($_SESSION['cart']); ?>;
            let message = "مرحباً، أود طلب المنتجات التالية:\n";
            cartItems.forEach(item => {
                message += `اسم المنتج: ${item.name}, السعر: ${item.price} ريال, العدد: ${item.quantity}, الإجمالي: ${item.price * item.quantity} ريال\n`;
            });
            message += `\nالإجمالي الكلي: ${<?php echo $totalPrice; ?>} ريال`;
            let phoneNumber = "+967777073957"; // استبدل هذه القيمة برقم هاتفك
            let url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
            window.open(url, "_blank");
        }
		

        // دالة لتأكيد إفراغ السلة
        function confirmClearCart() {
            if (confirm("هل أنت متأكد أنك تريد إفراغ السلة؟")) {
                window.location.href = "cart.php?clear=true";
            }
        }
    </script>
 <!-- Footer -->
 <?php include 'HeaderandFooter/footer.php'; ?>
 

