<?php
include 'db_connect.php';
include 'include/header.php';

// جلب الفئات من قاعدة البيانات لعرضها في القائمة المنسدلة
$class = [];
$result = $conn->query("SELECT class_id, class_name FROM class"); // جلب المعرف والاسم
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $class[] = $row; // حفظ كل صف كـ (معرّف + اسم الفئة)
    }
}

// إضافة منتج
if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $details = $_POST['details'];
    $quantity = $_POST['quantity'];
    $status = $_POST['status'];
    $class_id = $_POST['class_id']; // جلب class_id بدلاً من الاسم
    
    // رفع الصور
    $image1 = $_FILES['image1']['name'];

    $target_dir = "images/";
    move_uploaded_file($_FILES['image1']['tmp_name'], $target_dir . basename($image1));

    // إدراج المنتج مع ربطه بالفئة عبر class_id
    $sql = "INSERT INTO storyproducts (name, price, details, quantity, status, class_id, image1) 
            VALUES ('$name', '$price', '$details', '$quantity', '$status', '$class_id', '$image1')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('تم إضافة المنتج بنجاح!'); window.location.href='Admin_view_storyproducts.php';</script>";
    } else {
        echo "<script>alert('حدث خطأ أثناء الإضافة!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إضافة منتج</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>إضافة منتج</h1>
        </div>
    </header>
    <div class="container main">
        <form method="post" action="" enctype="multipart/form-data">
            <label>اسم المنتج:</label>
            <input type="text" name="name" required><br>
            <label>السعر:</label>
            <input type="text" name="price" required><br>
            <label>التفاصيل:</label>
            <textarea name="details" required></textarea><br>
            <label>الكمية:</label>
            <input type="number" name="quantity" required><br>
            <label>حالة المنتج:</label>
            <input type="text" name="status" required><br>
            <label>الفئة:</label>
            <select name="class_id" required>
                <?php foreach ($class as $class_row) { ?>
                    <option value="<?php echo $class_row['class_id']; ?>">
                        <?php echo $class_row['class_name']; ?>
                    </option>
                <?php } ?>
            </select><br>
            <label>صورة 1:</label>
            <input type="file" name="image1" required><br>
            <button type="submit" name="add">إضافة</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
