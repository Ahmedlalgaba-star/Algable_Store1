<?php
include 'db_connect.php';
include 'include/header.php';

// عرض المنتجات
$sql = "SELECT storyproducts.*, class.class_name 
        FROM storyproducts 
        INNER JOIN class ON class.class_id = storyproducts.class_id";
$result = $conn->query($sql);
?>
<body>

		
    
     <div class="container main">
        <h2>قائمة المنتجات</h2>
        <div class="products">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='product'>";
                    echo "<img src='images/" . $row["image1"] . "' alt='" . $row["name"] . "'>";
                    echo "<h2>" . $row["name"] . "</h2>";
                    echo "<p>السعر: $" . $row["price"] . "</p>";
                    echo "<p>" . $row["details"] . "</p>";
                    echo "<p>الكمية: " . $row["quantity"] . "</p>";
                    echo "<p>حالة المنتج: " . $row["status"] . "</p>";
					echo "<p>النوع: " . $row["class_id"] . " - " . $row["class_name"] . "</p>";
                    echo "<div class='actions'>";
                    echo "<a href='Admin_details.php?id=" . $row["id"] . "'>عرض التفاصيل</a>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>لا توجد منتجات</p>";
            }
            ?>
        </div>
    </div>
    
</body>
</html>

<?php
$conn->close();
?>
<?php include 'include/footer.php'; ?>