<?php
include 'db_connect.php';

// جلب بيانات المنتج للتعديل
$edit_product = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $sql = "SELECT * FROM storyproducts WHERE id=$id";
    $edit_result = $conn->query($sql);
    $edit_product = $edit_result->fetch_assoc();
}

// تعديل منتج
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $details = $_POST['details'];
    $quantity = $_POST['quantity'];
    $status = $_POST['status'];
    $class_id = $_POST['class_id'];
    
    // رفع الصور
    $image1 = $_FILES['image1']['name'] ? $_FILES['image1']['name'] : $edit_product['image1'];
     
    $target_dir = "images/";
    if ($_FILES['image1']['name']) {
        move_uploaded_file($_FILES['image1']['tmp_name'], $target_dir . basename($image1));
    }

    $sql = "UPDATE storyproducts SET name='$name', price='$price', details='$details', quantity='$quantity', status='$status',class_id='$class_id', image1='$image1' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('تم تعديل المنتج بنجاح!'); window.location.href='Admin_view_storyproducts.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تعديل منتج</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>تعديل منتج</h1>
        </div>
    </header>
    <div class="container main">
        <form method="post" action="" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $edit_product ? $edit_product['id'] : ''; ?>">
            <label>اسم المنتج:</label>
            <input type="text" name="name" value="<?php echo $edit_product ? $edit_product['name'] : ''; ?>" required><br>
            <label>السعر:</label>
            <input type="text" name="price" value="<?php echo $edit_product ? $edit_product['price'] : ''; ?>" required><br>
            <label>التفاصيل:</label>
            <textarea name="details" required><?php echo $edit_product ? $edit_product['details'] : ''; ?></textarea><br>
            <label>الكمية:</label>
            <input type="number" name="quantity" value="<?php echo $edit_product ? $edit_product['quantity'] : ''; ?>" required><br>
            <label>حالة المنتج:</label>
            <input type="text" name="status" value="<?php echo $edit_product ? $edit_product['status'] : ''; ?>" required><br> 
			<label>النوع:</label>
            <input type="text" name="class_id" value="<?php echo $edit_product ? $edit_product['class_id'] : ''; ?>" required><br>
            <label>صورة 1:</label>
            <input type="file" name="image1"><br>
            <button type="submit" name="update">تعديل</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
