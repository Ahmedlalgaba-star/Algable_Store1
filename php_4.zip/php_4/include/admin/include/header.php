<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الصفحة الرئيسية</title>
	  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
	  <meta name=thhp-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

    <header>


        <nav>

            <ul>
			    <li><a href="‏‏‏‏Admin_add_class.php">إضافة قسم جديد</a></li>
                <li><a href="Admin_add_storyproducts.php">إضافة منتج</a></li>
                <li><a href="Admin_view_storyproducts.php">عرض المنتجات </a></li>
                <li><a href="login.php">تسجيل الخروج</a></li>
         
            </ul>

        </nav>
       
    </header>