 //القائمة الجنبية للشاشات الصغار
 function toggleMenu() {
            var menu = document.getElementById('mobile-nav');
            var hamburger = document.querySelector('.hamburger-menu');

            menu.classList.toggle('active');
            hamburger.classList.toggle('active');
        }