<?php
include 'db_connect.php';
include 'include/header.php';

// عرض المنتجات
$sql = "SELECT * FROM storyproducts";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>عرض منتجات القصص والروايات</title>
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>
    <header>
        <div class="container">
            <h1>عرض منتجات القصص والروايات</h1>
        </div>
    </header>
    <div class="container main">
      
        <h2>قائمة منتجات القصص والروايات</h2>
        <div class="products">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='product'>";
                    echo "<img src='images/" . $row["image1"] . "' alt='" . $row["name"] . "'>";
                    echo "<h2>" . $row["name"] . "</h2>";
                    echo "<p>السعر: $" . $row["price"] . "</p>";
                    echo "<p>" . $row["details"] . "</p>";
                    echo "<p>الكمية: " . $row["quantity"] . "</p>";
                    echo "<p>حالة المنتج: " . $row["status"] . "</p>";
                    echo "<div class='actions'>";
                    echo "<a href='Admin_details.php?id=" . $row["id"] . "'>عرض التفاصيل</a>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>لا توجد منتجات</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
<?php include 'include/footer.php'; ?>