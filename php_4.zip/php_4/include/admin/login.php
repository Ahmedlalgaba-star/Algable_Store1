<!--Server Side Scripting Language to inject login code-->
<?php
      $dbuser="root";
      $dbpass="";
      $host="localhost";
      $db="store";
      $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
      
      ?>
<?php


      
          if(isset($_POST['add-login']))
    {
      $email=$_POST['email'];
      $password=($_POST['password']);
      $stmt=$mysqli->prepare("SELECT email, password,username,id FROM users WHERE email=? and password=?");//sql to log in user
      $stmt->bind_param('ss',$email,$password);//bind fetched parameters
      $stmt->execute();//execute bind
      $stmt -> bind_result($email,$password,$username,$id);//bind result
      $rs=$stmt->fetch();
      $_SESSION['id']=$id;//تسجيل جلسه للمورد
      $_SESSION['username']=$username;//assaign session to admin id
	 
      //$uip=$_SERVER['REMOTE_ADDR'];
      //$ldate=date('d/m/Y h:i:s', time());
      if($rs)
      {//if its sucessfull
        header("location:Admin_view_storyproducts.php");//يتم الدخول الي لوحة التحكم الخاصه بالادمن
      }

      else
      {
      #echo "<script>alert('Access Denied Please Check Your Credentials');</script>";
      $error = "خطاء";
      }
  }
?>
<!--End Server side-->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>تسجيل الدخول للادمن</title>
  <link rel="stylesheet" href="css/style1.css">
</head>

<body>
<?php if(isset($error)) {?>
  <!--This code for injecting an alert-->
      <script>
            setTimeout(function () 
            { 
              swal("كلمة المرور او الرمز خطأ!","<?php echo $error;?>!","error");
            },
              100);
      </script>
					
  <?php } ?>
  <div class="container">
    <div class="form-box box">

      
        <header>تسجيل الدخول</header>
        <hr>
        <form method="POST">

          <div class="form-box">


            <div class="input-container">
              
              <input class="input-field" style="text-align:right" type="email" placeholder="البريد الإلكتروني" name="email" required="required" autofocus="autofocus">
            </div>

            <div class="input-container">
              <i class="fa fa-eye icon toggle" style="text-align:left">إخفاء</i>
              <input class="input-field password" style="text-align:right" placeholder="كلمة المرور" required name="password"/>
             
            </div>

            <div class="remember" >
              <input style="text-align:right" type="checkbox" class="check" name="remember_me">
              <label for="remember">تذكر كلمة المرور</label>
              
            </div>

          </div>


			<center><input type="submit" name="add-login" id="submit" value="دخول" class="btn"></center>

      <div class="links">
           <a href="../shop.php">الصفحة الرئيسية</a>
          </div>
       

        </form>
      </div>
        </div>
  <script>
    const toggle = document.querySelector(".toggle"),
      input = document.querySelector(".password");
    toggle.addEventListener("click", () => {
      if (input.type === "password") {
        input.type = "text";
        toggle.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        input.type = "password";
      }
    })
  </script>
  
   
  <!--Sweet alerts js-->
  <script src="js/swal.js"></script>
</body>

</html>