<?php
include 'db_connect.php';

// حذف منتج
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM storyproducts WHERE id=$id";
    $conn->query($sql);
    echo "<script>alert('تم حذف المنتج بنجاح!'); window.location.href='Admin_view_storyproducts.php';</script>";
}

// عرض المنتجات
$sql = "SELECT * FROM storyproducts";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>حذف منتج</title>
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>
    <header>
        <div class="container">
            <h1>حذف منتج</h1>
        </div>
    </header>
    <div class="container main">
        <h2>قائمة المنتجات</h2>
        <div class="products">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='product'>";
                    echo "<h2>" . $row["name"] . "</h2>";
                    echo "<p>السعر: $" . $row["price"] . "</p>";
                    echo "<p>" . $row["details"] . "</p>";
                    echo "<p>الكمية: " . $row["quantity"] . "</p>";
                    echo "<p>حالة المنتج: " . $row["status"] . "</p>";
                    echo "<div class='images'>";
                    echo "<img src='images/" . $row["image1"] . "' alt='" . $row["name"] . "'>";
                    echo "<img src='images/" . $row["image2"] . "' alt='" . $row["name"] . "'>";
                    echo "<img src='images/" . $row["image3"] . "' alt='" . $row["name"] . "'>";
                    echo "</div>";
                    echo "<div class='actions'>";
                    echo "<a href='Admin_delete.php?delete=" . $row["id"] . "'>حذف</a>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "<p>لا توجد منتجات</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
