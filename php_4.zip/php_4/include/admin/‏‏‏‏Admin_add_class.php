<?php
include 'db_connect.php';
include 'include/header.php';
// إضافة قسم
if (isset($_POST['add'])) {
    $name = $_POST['name'];

    $sql = "INSERT INTO class (name) VALUES ('$name')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('تم إضافة القسم القسم بنجاح!'); window.location.href='‏‏‏‏Admin_add_class.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إضافة قسم</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>إضافة قسم</h1>
        </div>
    </header>
    <div class="container main">
        <form method="post" action="" enctype="multipart/form-data">
            <label>اسم القسم:</label>
            <input type="text" name="name" required><br>

            <button type="submit" name="add">إضافة</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
