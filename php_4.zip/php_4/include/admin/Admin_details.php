<?php
include 'db_connect.php';

// جلب تفاصيل المنتج
$product = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM storyproducts WHERE id=$id";
    $result = $conn->query($sql);
    $product = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل المنتج</title>
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>
    <header>
        <div class="container">
            <h1>تفاصيل المنتج</h1>
        </div>
    </header>
    <div class="container main">
        <?php if ($product): ?>
            <div class="product">
                <img src="images/<?php echo $product['image1']; ?>" alt="<?php echo $product['name']; ?>">
                <h2><?php echo $product['name']; ?></h2>
                <p>السعر: $<?php echo $product['price']; ?></p>
                <p><?php echo $product['details']; ?></p>
                <p>الكمية: <?php echo $product['quantity']; ?></p>
                <p>حالة المنتج: <?php echo $product['status']; ?></p>
                <div class="actions">
                    <a href="Admin_edit.php?edit=<?php echo $product['id']; ?>">تعديل</a>
                    <a href="Admin_delete.php?delete=<?php echo $product['id']; ?>">حذف</a>
                </div>
                <div class="back-button">
    <a href="Admin_view_storyproducts.php">رجوع إلى صفحة عرض المنتجات</a>
</div>
            </div>
            
        <?php else: ?>
            <p>لم يتم العثور على المنتج.</p>
        <?php endif; ?>
    </div>
    
</body>
</html>

<?php
$conn->close();
?>
