// ✅ دالة لعرض محتويات السلة بشكل احترافي
function showCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const cartContent = document.getElementById("cart-content");

    if (!cartContent) return;

    if (cart.length > 0) {
        let total = 0;
        const itemsHTML = cart.map((item, index) => {
            total += parseFloat(item.price);
            return `
                <li class="cart-item">
                    <span class="item-name">${item.name}</span>
                    <span class="item-price">${item.price} ريال</span>
                    <button class="remove-item" onclick="removeFromCart(${index})">🗑️</button>
                </li>
            `;
        }).join("");

        cartContent.innerHTML = `
            <ul class="cart-list">${itemsHTML}</ul>
            <div class="cart-total">
                الإجمالي: <strong>${total.toFixed(2)} ريال</strong>
            </div>
            <button class="clear-cart" onclick="clearCart()">🧹 تفريغ السلة</button>
        `;
    } else {
        cartContent.innerHTML = "<p class='empty-cart'>السلة فارغة 🛒</p>";
    }
}

// ✅ دالة لحذف عنصر من السلة
function removeFromCart(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    showCart();
}

// ✅ دالة لتفريغ السلة بالكامل
function clearCart() {
    localStorage.removeItem("cart");
    showCart();
}

// ✅ تشغيل العرض عند تحميل الصفحة (اختياري)
document.addEventListener("DOMContentLoaded", showCart);
