<!DOCTYPE html>
<html lang="ar">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سلة التسوق</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
	<link rel="stylesheet" href="css/header.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="css/table.css">
<link rel="stylesheet" href="css/search.css" />
</head>

<body>

    <!-- Header -->
    <header>
        <div class="logo">متجر الجبل الكتروني</div>
<br>
        <!-- زر الهامبرغر -->
        <div class="hamburger-menu" onclick="toggleMenu()">
            <div></div>
            <div></div>
            <div></div>
        </div>

        <!-- الروابط العادية -->
        <div class="nav-links">
            <a href="shop.php">الصفحة الرئيسية</a>
            <a href="cart.php">سلة التسوق</a>
            <a href="contact.php">اتصل بنا</a>
        </div>

        <!-- قائمة الجوال -->
        <div class="mobile-nav" id="mobile-nav">
            <span class="close-menu" onclick="toggleMenu()">&times;</span>
            <a href="admin/login.php">الادمن</a>
            <a href="shop.php">الصفحة الرئيسية</a>
			<a href="shop.php">جميع المنتجات</a>
            <a href="storyproducts.php">ملابس عطورات</a>
            <a href="mbusinproducts.php"> الهواتف الذكية ومستلزماتها</a>
            <a href="sdevelopproducts.php">ادوات منزلية</a>
            <a href="cart.php">سلة التسوق</a>
            <a href="contact.php">اتصل بنا</a>
        </div>
		  <div class="search-container">
        <form method="GET" action="">
            <input type="input" name="search" placeholder="🔍 ابحث عن منتج..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
            <button type="submit">
                🔍 <!-- أيقونة البحث -->
            </button>
        </form>
    </div>
	
	   <div class="cart-btn-container">
        <a href="cart.php" class="cart-btn">
            <i class="fas fa-shopping-cart"></i> 
            <span class="cart-text">سلتي</span>
            <span class="cart-count">
                <?php echo isset($_SESSION['cart']) ? '(' . count($_SESSION['cart']) . ')' : '(0)'; ?>
            </span>
        </a>
    </div>
    </header>
<br>
<br>
